=== Woocommerce Linkwise Connection ===
Contributors: kbariotis
Tags: woocommerce, linkwise, connection, ad platform
Tested up to: 4
License: GNU GPL v2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Inject appropriate scripts for connecting with Linkwise\'s platform

== Description ==
Inject appropriate scripts for connecting with Linkwise\'s platform — Edit


== Installation ==
Install either by extracting on your wp-content/plugins/ folder or using the default uploader.

Add you Linkwise ID at Settings->Linkwise Settings page.

== Changelog ==
0.1 : Bing Bang